<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'digicards';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = '';
$config['db']['port'] = '';

$config['version'] = '1.3';
$config['installed'] = '1';