<?php
/*
Copyright (c)
*/
require_once('includes.php');

// initilize all variable
$params = $columns = $totalRecords = $data = array();
$params = $_REQUEST;

//define index of column
$columns = array(
	0 =>'id',
	1 =>'product_title',
	2 =>'price',
	3 =>'product_description',
	4 =>'activate'
);

$where = $sqlTot = $sqlRec = "";

// check search value exist
if( !empty($params['search']['value']) ) {
	$where .=" WHERE ";
	$where .=" ( price LIKE '".$params['search']['value']."%' ";
	$where .=" OR product_title LIKE '".$params['search']['value']."%' ";
	$where .=" OR product_description LIKE '".$params['search']['value']."%' ";
	$where .=" OR product_plans LIKE '".$params['search']['value']."%' ";

	$where .=" OR activate LIKE '".$params['search']['value']."%' )";
}

// getting total number records without any search
$sql = "SELECT * FROM `".$config['db']['pre']."product_info`";
$sqlTot .= $sql;
$sqlRec .= $sql;
//concatenate search sql if value exist
if(isset($where) && $where != '') {

	$sqlTot .= $where;
	$sqlRec .= $where;
}


$sqlRec .=  " ORDER BY ". $columns[$params['order'][0]['column']]."   ".$params['order'][0]['dir']." LIMIT ".$params['start']." ,".$params['length']." ";

$queryTot = $pdo->query($sqlTot);
$totalRecords = $queryTot->rowCount();
$queryRecords = $pdo->query($sqlRec);

//iterate on results row and create new index array of data
foreach ($queryRecords as $row) {
	
	$id = $row['id'];
	$product_title = $row['product_title'];
	$name = $row['product_description'];
	$price = $row['price'];
	$product_plans = ( !empty( $row['product_plans'] ) ? str_replace('_', ' ', ( implode( ', ', json_decode( $row['product_plans'] )))) : '' );
	$status = $row['activate'];

	$install_button = "";

	if ($status == 1){
		$status = '<span class="label label-success">Activated</span>';
	}
	elseif($status == 0)
	{
		$status = '<span class="label label-warning">Not Active</span>';
	}



	$row0 = '<td><img class="redux-option-image" src="./product-images/'.$row['product_image'].'" alt="" width="60px"></td>';
	$row1 = '<td>'.$product_title.' '.$status.'</td>';
	$row2 = '<td>'.$name.'</td>';
	$row3 = '<td>'.$price.'</td>';
	$row4 = '<td>'.$product_plans.'</td>';
	$row5 = '<td class="text-center">
	<div class="btn-group">
	<a href="javascript:void(0)" data-url="panel/product_edit.php?product_id='.base64_encode( bin2hex( $id ) ).'" data-toggle="slidePanel" class="btn btn-xs btn-default"> <i class="ion-edit"></i> Edit</a><a href="javascript:void(0)" class="ml-2 btn btn-xs btn-danger item-js-delete" data-ajax-action="deleteProduct"> <i class="ion-close"></i> Delete</a>
	</div>
	</td>';

	$value = array(
		"DT_RowId" => $id,
		0 => $row0,
		1 => $row1,
		2 => $row2,
		3 => $row3,
		4 => $row4,
		5 => $row5
	);
	$data[] = $value;
}


$json_data = array(
	"draw"            => intval( $params['draw'] ),
	"recordsTotal"    => intval( $totalRecords ),
	"recordsFiltered" => intval($totalRecords),
    "data"            => $data   // total data array
);

echo json_encode($json_data);  // send data as json format
?>
