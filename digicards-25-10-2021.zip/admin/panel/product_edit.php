<?php
require_once('../datatable-json/includes.php');

if( empty( $_GET[ 'product_id' ] )){
    return false;
}

$product_id = hex2bin( base64_decode( $_GET[ 'product_id' ] ));
$info = ORM::for_table($config['db']['pre'].'product_info')
->where('id',$product_id )
->find_one();

$query = "SELECT * FROM `".$config['db']['pre']."plans` ";
$plans = ORM::for_table($config['db']['pre'].'plans')->select('name')->find_many($_POST['id']);

$free_plan = json_decode(get_option('free_membership_plan'), true);
$trial_plan = json_decode(get_option('trial_membership_plan'), true);

$plan_arr = array();
$plan_arr[] = ( isset( $free_plan['name'] ) ? $free_plan['name'] : '' ); 
$plan_arr[] = ( isset( $trial_plan['name'] ) ? $trial_plan['name'] : '' ); 

if( !empty($plans ) ){
    foreach ( $plans as $key => $plan) {
        $plan_arr[] = $plan['name'];
    }
} ?>
<header class="slidePanel-header overlay">
    <div class="overlay-panel overlay-background vertical-align">
        <div class="service-heading">
            <h2>Product Edit - Settings</h2>
        </div>
        <div class="slidePanel-actions">
            <div class="btn-group-flat">
                <button type="button" class="btn btn-floating btn-warning btn-sm waves-effect waves-float waves-light margin-right-10" id="post_sidePanel_data"><i class="icon ion-android-done" aria-hidden="true"></i></button>
                <button type="button" class="btn btn-pure btn-inverse slidePanel-close icon ion-android-close font-size-20" aria-hidden="true"></button>
            </div>
        </div>
    </div>
</header>
<div class="slidePanel-inner">
    <div class="panel-body">
        <!-- /.row -->
        <div class="row">
            <div class="col-sm-12">

                <div class="white-box">
                    <div id="post_error"></div>
                    <form name="form2"  class="form" method="post" data-ajax-action="addProduct" id="sidePanel_form">
                        <div class="form-body">
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Activate</label>
                                <div class="col-sm-8">
                                    <label class="css-input switch switch-sm switch-success">
                                        <input  name="active" type="checkbox" value="1" <?php echo ( isset( $info[ 'activate' ] ) && !empty( $info[ 'activate' ] ) ? 'checked' : '' ); ?> /><span></span>
                                    </label>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Product Name</label>
                                <div class="col-sm-8">
                                    <input name="product_name" type="Text" class="form-control" placeholder="Product Name" value="<?php echo ( isset( $info[ 'product_title' ] ) && !empty( $info[ 'product_title' ] ) ? $info[ 'product_title' ] : '' ); ?>" >
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Product Description</label>
                                <div class="col-sm-8">
                                    <textarea name="product_description" id="product_description" rows="5" cols="30"><?php echo ( isset( $info[ 'product_description' ] ) && !empty( $info[ 'product_description' ] ) ? $info[ 'product_description' ] : '' ); ?></textarea>
                                    <p class="help-block">Product Description.</p>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Product Price</label>
                                <div class="col-sm-8">
                                    <input name="product_price" type="number" class="form-control" id="product_price" placeholder="Product Price" value="<?php echo ( isset( $info[ 'price' ] ) && !empty( $info[ 'price' ] ) ? $info[ 'price' ] : '' ); ?>">
                                    <p class="help-block">Set Product Price.</p>
                                </div>
                            </div>
                            <?php 
                            $product_plans = ( !empty( $info[ 'product_plans' ] ) ? json_decode( $info[ 'product_plans' ], true ) : array() );
                            if( !empty( $plan_arr ) ){ ?>
                                <div class="row form-group">
                                    <label class="col-sm-4 control-label">Product Plans*</label>
                                    <div class="col-sm-8">
                                        <select style="" id="product_plans" name="product_plans[]" class="form-control select short" multiple>
                                            <?php
                                            foreach ($plan_arr as $key => $plan) {
                                                $selected = ( in_array( str_replace(' ', '_', $plan), $product_plans ) ? ' selected' : '' );
                                                echo '<option value="'.str_replace(' ', '_', $plan).'"'.$selected.'>'.$plan.'</option>';
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php $image = $info[ 'product_image' ] ?>
                            <div class="form-group">
                                <label for="post_image">Product Image*</label>
                                <span class="help-block">Only jpg, jpeg & png allowed.</span>
                                <div>
                                    <img class="redux-option-image" id="post_image" src="<?php echo './product-images/'.$image; ?>" alt="" width="100px">
                                </div>
                                <input class="form-control input-sm" type="file" name="product_image"
                                onchange="readURL(this,'post_image')">
                            </div>
                            <?php $images = json_decode( $info[ 'product_gallery' ], true ); ?>
                            <div class="form-group">
                                <label for="post_gallery">Product Gallery Image*</label>
                                <span class="help-block">Only jpg, jpeg & png allowed.</span>
                                <div class="post_gallery_images">
                                    <?php
                                    foreach ($images as $key => $image) { ?>
                                        <img class="redux-option-image" src="<?php echo './product-images/'.$image; ?>" alt="" width="100px">
                                    <?php } ?>
                                    <img class="redux-option-image" id="post_gallery" src="" alt="" width="100px" style="display: none">
                                </div>
                                <input class="form-control input-sm" type="file" name="product_gallery_image[]" multiple 
                                onchange="read_multi_URL(this,'post_gallery')">
                            </div>
                            <input type="hidden" name="id" value="<?php echo $product_id; ?>">
                            <input type="hidden" name="submit">
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
</div>
<script>
    $(function()
    {
        App.initHelpers('select2');
        $("#product_plans").select2();
    });
</script>