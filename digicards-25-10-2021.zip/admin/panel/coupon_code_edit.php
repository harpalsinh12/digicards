<?php
require_once('../datatable-json/includes.php');

if( empty( $_GET[ 'coupon_id' ] )){
    return false;
}

$coupon_id = hex2bin( base64_decode( $_GET[ 'coupon_id' ] ));
$info = ORM::for_table($config['db']['pre'].'coupon_code')
->where('id',$coupon_id )
->find_one(); ?>
<header class="slidePanel-header overlay">
    <div class="overlay-panel overlay-background vertical-align">
        <div class="service-heading">
            <h2>Add Coupon Code</h2>
        </div>
        <div class="slidePanel-actions">
            <div class="btn-group-flat">
                <button type="button" class="btn btn-floating btn-warning btn-sm waves-effect waves-float waves-light margin-right-10" id="post_sidePanel_data"><i class="icon ion-android-done" aria-hidden="true"></i></button>
                <button type="button" class="btn btn-pure btn-inverse slidePanel-close icon ion-android-close font-size-20" aria-hidden="true"></button>
            </div>
        </div>
    </div>
</header>
<div class="slidePanel-inner">
    <div class="panel-body">
        <!-- /.row -->
        <div class="row">
            <div class="col-sm-12">

                <div class="white-box">
                    <div id="post_error"></div>
                    <form name="form2"  class="form" method="post" data-ajax-action="addCouponCode" id="sidePanel_form">
                        <div class="form-body">
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Activate</label>
                                <div class="col-sm-8">
                                    <label class="css-input switch switch-sm switch-success">
                                        <input  name="active" type="checkbox" value="1" <?php echo ( isset( $info[ 'active' ] ) && !empty( $info[ 'active' ] ) ? 'checked' : '' ); ?> /><span></span>
                                    </label>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Coupon Name*</label>
                                <div class="col-sm-8">
                                    <input name="cc_name" type="Text" class="form-control" placeholder="Coupon Name" value="<?php echo ( isset( $info[ 'coupon_name' ] ) && !empty( $info[ 'coupon_name' ] ) ? $info[ 'coupon_name' ] : '' ); ?>">
                                </div>
                            </div>                            
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Discount type*</label>
                                <div class="col-sm-8">
                                    <select style="" id="discount_type" name="discount_type" class="form-control select short">
                                        <option value="percent" <?php echo ( isset( $info[ 'discount_type' ] ) && $info[ 'discount_type' ] == 'percent' ? 'selected' : '' ); ?>>Percentage discount</option>
                                        <option value="fixed_cart" <?php echo ( isset( $info[ 'discount_type' ] ) && $info[ 'discount_type' ] == 'fixed_cart' ? 'selected' : '' ); ?>>Fixed cart discount</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Coupon amount*</label>
                                <div class="col-sm-8">
                                    <input name="cc_amount" type="number" class="form-control" placeholder="Coupon amount" value="<?php echo ( isset( $info[ 'discount_amount' ] ) && !empty( $info[ 'discount_amount' ] ) ? $info[ 'discount_amount' ] : '' ); ?>">
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Coupon expiry date</label>
                                <div class="col-sm-8">
                                    <input name="cc_expiry_date" id="datepicker" type="text" class="form-control" placeholder="Coupon expiry date" value="<?php echo ( isset( $info[ 'coupon_expiry_date' ] ) && !empty( $info[ 'coupon_expiry_date' ] ) ? $info[ 'coupon_expiry_date' ] : '' ); ?>" >
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Usage limit per user</label>
                                <div class="col-sm-8">
                                    <input name="cc_limit_per_user" type="number" class="form-control" placeholder="Usage limit per user" value="<?php echo ( isset( $info[ 'limit_per_user' ] ) && !empty( $info[ 'limit_per_user' ] ) ? $info[ 'limit_per_user' ] : '' ); ?>">
                                </div>
                            </div>        
                            <input type="hidden" name="id" value="<?php echo $coupon_id; ?>">
                            <input type="hidden" name="submit">
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
</div>
<script>
    $(function()
    {
        App.initHelpers('select2');
        $( "#datepicker" ).datepicker({minDate:0}).datepicker( 'setDate', '<?php echo $info[ 'coupon_expiry_date' ]; ?>');
    });
</script>