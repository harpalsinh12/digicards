<?php
require_once('../datatable-json/includes.php');
?>
<header class="slidePanel-header overlay">
    <div class="overlay-panel overlay-background vertical-align">
        <div class="service-heading">
            <h2>Add Coupon Code</h2>
        </div>
        <div class="slidePanel-actions">
            <div class="btn-group-flat">
                <button type="button" class="btn btn-floating btn-warning btn-sm waves-effect waves-float waves-light margin-right-10" id="post_sidePanel_data"><i class="icon ion-android-done" aria-hidden="true"></i></button>
                <button type="button" class="btn btn-pure btn-inverse slidePanel-close icon ion-android-close font-size-20" aria-hidden="true"></button>
            </div>
        </div>
    </div>
</header>
<div class="slidePanel-inner">
    <div class="panel-body">
        <!-- /.row -->
        <div class="row">
            <div class="col-sm-12">

                <div class="white-box">
                    <div id="post_error"></div>
                    <form name="form2"  class="form" method="post" data-ajax-action="addCouponCode" id="sidePanel_form">
                        <div class="form-body">
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Activate</label>
                                <div class="col-sm-8">
                                    <label class="css-input switch switch-sm switch-success">
                                        <input  name="active" type="checkbox" value="1" checked /><span></span>
                                    </label>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Coupon Name*</label>
                                <div class="col-sm-8">
                                    <input name="cc_name" type="Text" class="form-control" placeholder="Coupon Name">
                                </div>
                            </div>                            
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Discount type*</label>
                                <div class="col-sm-8">
                                    <select style="" id="discount_type" name="discount_type" class="form-control select short">
                                        <option value="percent">Percentage discount</option>
                                        <option value="fixed_cart" selected="selected">Fixed cart discount</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Coupon amount*</label>
                                <div class="col-sm-8">
                                    <input name="cc_amount" type="number" class="form-control" placeholder="Coupon amount" value="">
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Coupon expiry date</label>
                                <div class="col-sm-8">
                                    <input name="cc_expiry_date" id="datepicker" type="text" class="form-control" placeholder="Coupon expiry date" value="" >
                                </div>
                            </div>
                            <div class="row form-group">
                                <label class="col-sm-4 control-label">Usage limit per user</label>
                                <div class="col-sm-8">
                                    <input name="cc_limit_per_user" type="number" class="form-control" placeholder="Usage limit per user" value="">
                                </div>
                            </div>                            
                            <input type="hidden" name="submit">
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
</div>
<script>
    $(function()
    {
        App.initHelpers('select2');
        $( "#datepicker" ).datepicker({minDate:0});
    });
</script>